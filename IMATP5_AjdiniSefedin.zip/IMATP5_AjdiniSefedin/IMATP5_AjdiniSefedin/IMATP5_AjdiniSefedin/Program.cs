﻿using System;

namespace IMATP5_AjdiniSefedin
{
    class Program
    {
        static void Main(string[] args)
        {
            outils mesOutils = new outils();
            int[,] grille; /// creation grille
            int degre;
            int val1 = 0;
            int val2 = 0;
            bool test;
            string stringTab;
            do
            {
                    mesOutils.LireReel("veuillez saisir le degre desirer", out degre);
                    mesOutils.TrianglePascal(out grille, degre, out test, val1, val2);
                    mesOutils.String_Tableau(grille, out stringTab);
                    Console.WriteLine(stringTab);
            } while (true);
        }
    }
}
