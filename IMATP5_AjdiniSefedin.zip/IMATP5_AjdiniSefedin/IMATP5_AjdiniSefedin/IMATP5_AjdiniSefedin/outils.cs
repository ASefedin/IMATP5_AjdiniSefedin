﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMATP5_AjdiniSefedin
{
    public struct outils
    {
        /// <summary>
        /// permet de lire un nombre 
        /// </summary>
        /// <param name="question">c'est ce qui va etre demande a l'utilisateur</param>
        /// <param name="n">valeur resultat</param>
        public void LireReel(string question, out int n)
        {
            string nUser;
            Console.Write(question);
            nUser = Console.ReadLine();
            while (!int.TryParse(nUser, out n))
            {
                Console.WriteLine("Attention ! vous devez taper un nombre réel !");
                nUser = Console.ReadLine();
            }
        }

        public void String_Tableau(int[,] grille, out string stringTab)
        {
            stringTab = "";
            for (int ligne = 0; ligne < grille.GetLength(0); ligne++)
            {
                for (int colonne = 0; colonne < grille.GetLength(1); colonne++)
                {
                    stringTab += grille[ligne, colonne] + "|";
                }
                stringTab += "\n";
            }
        }
        public void TrianglePascal(out int[,] grille, int degre, out bool test, int val1, int val2)
        {
            test = true;
            val1 = int.Parse(Console.ReadLine());
            val2 = val1 + 1;
            grille = new int[val2, val2];
            degre = (val1 + 1) * 2;
            for (int i = 0; i < val2; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    if (i > 0)
                    {
                        if (j == 0 || j == i - 1)
                        {
                            grille[i, j] = 1;
                        }
                    }
                    if (j > 0 && i > 0 && (j != 0 || j != i - 1))
                    {
                        grille[i, j] = grille[i - 1, j - 1] + grille[i - 1, j];
                    }
                }
            }
            for (int i = 0; i < val2; i++)
            {
                string degrePR = new string(' ', degre);
                Console.Write(degrePR);
                for (int j = 0; j < val2; j++)
                {
                    if (grille[i, j] != 0)
                    {
                        if (grille[i, j] < 10)
                        {
                            Console.Write("{0}   ", grille[i, j]);
                        }
                        else if (grille[i, j] > 9 && grille[i, j] < 100)
                        {
                            Console.Write("{0}  ", grille[i, j]);
                        }
                        else Console.Write("{0} ", grille[i, j]);
                    }
                }
                Console.WriteLine();
                degre -= 2;
            }
            test = false;
        }
    }
}
